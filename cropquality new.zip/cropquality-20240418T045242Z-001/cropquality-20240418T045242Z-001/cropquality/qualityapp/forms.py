from django import forms
# from .models import Notification

# class NotificationForm(forms.ModelForm):
#     class Meta:
#         model = Notification
#         fields = ['title', 'content']


# forms.py
from django import forms

class ImageForm(forms.Form):
    image = forms.ImageField(label='Upload Image')
    words = forms.CharField(label='Enter range:', max_length=100)
