
import json
import tempfile
from django.shortcuts import render,redirect
from . models import regist
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
import cv2
import base64
# Create your views here.
def index(request):
    return render(request,'index.html')
def register(request):
    if request.method=='POST':
      name = request.POST.get('Name')
      email = request.POST.get('email')
      password = request.POST.get('password')
      regist(name=name,email=email,password=password).save()
      alert_message = "<script>alert('Registration Successful!'); window.location.href='/login';</script>"

        # Return the alert message as HttpResponse
      return HttpResponse(alert_message)
      return render(request,'login.html')
    else:
      return render(request,'register.html')
def login(request):
   if request.method=='POST':
      email = request.POST.get('email')
      password = request.POST.get('password')
      cr = regist.objects.filter(email=email,password=password)
      if cr:
         details = regist.objects.get(email=email,password=password)
         email = details.email
         request.session['cs']=email

         return render(request,'userhome.html')
      else:
         message="Invalid Username Or Password"
         return render(request,'login.html',{'me':message})
   else: 
      return render(request,'login.html')
   
def userhome(request):
   return render(request,'userhome.html')



from django.shortcuts import render
from .forms import ImageForm
import requests



API_URL = "https://api-inference.huggingface.co/models/linkanjarad/mobilenet_v2_1.0_224-plant-disease-identification"
headers = {"Authorization": "Bearer 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"}

def query(filename):
    with open(filename, "rb") as f:
        data = f.read()
    response = requests.post(API_URL, headers=headers, data=data)
    return response.json()



def remove_words_from_string(text, words_to_remove):
    for word in words_to_remove:
        text = text.replace(word, '')
    return text.strip()

def remove_words(output, words_to_remove):
    if isinstance(output, dict):
        return {key: remove_words(value, words_to_remove) for key, value in output.items()}
    elif isinstance(output, list):
        return [remove_words(item, words_to_remove) for item in output]
    elif isinstance(output, str):
        return remove_words_from_string(output, words_to_remove)
    else:
        return output

output = query("C:\\Users\\vaiva\\OneDrive\\Desktop\\office files\\cropquality-20240418T045242Z-001\\WheatQuality-20240418T065958Z-001\\WheatQuality\\images\\bacteria.jpeg")



# List of words to remove
words_to_remove = ['powdery mildew', 'Loose smut','Stripe rust','Blackrust','Brown rust','Flag Smut','Foot Root','foot root','Head scrab','wheat','hill bunt','seeding blight','Leaf blotch','Wheat']

# Remove the specified words from each label
output_without_words = [{'label': ' '.join([word for word in entry['label'].split() if word not in words_to_remove]), 'score': entry['score']} for entry in output]




print(output_without_words)

import random
from .models import UploadedImage
from .forms import ImageForm
import requests
from .models import UploadedImage


def process_image(request):
    if request.method == 'POST':
        form = ImageForm(request.POST, request.FILES)
        if form.is_valid():
            image_file = form.cleaned_data['image']
            # img_instance=UploadedImage()
            # img_instance.image=image_file
            # img_instance.save()
            print(image_file)
            # print(img_instance)
            words_to_remove = form.cleaned_data['words'].split(',')
            output = query(image_file)

            output_without_words = remove_words(output, words_to_remove)
            
            print(output_without_words)
            a=output_without_words[0]['score']
    
            scores = [entry['score'] for entry in output_without_words]


            print("Scores:", scores)
            

            # Calculate grade
            possible_grades = ['A', 'B', 'C', 'D']

            # Randomly select a grade from the list
            grade = random.choice(possible_grades)
            for entry in output_without_words:
                if entry['label'] == 'Healthy Plant':
                    if entry['score'] > 0.5:
                        grade = 'Grade A'
                        break
                    elif entry['score'] > 0.25:
                        grade = 'Grade B'
                    elif entry['score'] > 0.15:
                        grade = 'Grade C'
                    elif entry['score'] > 0.01:
                        grade = 'Grade D'

            print("Output without words:", output_without_words)
            print("Grade:", grade)  # Print the grade
            img_instance = UploadedImage.objects.create(image=image_file)
            
            # Pass the uploaded image to the template context
            return render(request, 'op.html', {'output': a, 'grade': grade,'uploaded_image':img_instance})
    else:
        form = ImageForm()
    return render(request, 'input.html', {'form': form})

def query(image_file):
    data = image_file.read()  # Read the content of the InMemoryUploadedFile
    response = requests.post(API_URL, headers=headers, data=data)
    return response.json()


def op(request):
    return render(request,'op.html')
def op1(request):
    return render(request,'op1.html')

 
import os
from django.conf import settings
from django.core.files.base import ContentFile
def capture_image(request):
    if request.method == 'POST':
        # Use OpenCV to capture an image from the camera
        cap = cv2.VideoCapture(0)
        ret, frame = cap.read()
        cap.release()

        # Create a temporary directory to store the captured image
        image_data = cv2.imencode('.jpg', frame)[1].tobytes()

        # Create a ContentFile object from the image data
        image_file = ContentFile(image_data, name='captured_image.jpg')

        # Save the image into Django's File object
        img_instance = UploadedImage.objects.create(image=image_file)
        # Optionally, you can redirect to a success page
        return redirect('capturedimage')
    else:
        return render(request, 'livecapture.html')


def livecapture(request):
    return render(request, 'livecapture.html')

def capturedimage(request):
    # Get the last uploaded image from the UploadedImage table
    try:
        latest_image = UploadedImage.objects.latest('uploaded_at')
        late_img= latest_image.image.path
        print(latest_image)
        print(late_img)
       
    except UploadedImage.DoesNotExist:
        latest_image = None
        late_img= None

    # Pass the image object to the template for rendering
    return render(request, 'capturedimage.html', {'latest_image_url': latest_image})

def cprediction(request):
    latest_image = UploadedImage.objects.last()
    if latest_image:
        output = query(latest_image.image)
        output_without_words = remove_words(output, [])
        a = None
        if output_without_words:
                a = output_without_words[0].get('score', None)
        
        possible_grades = ['A', 'B', 'C', 'D']
        grade = random.choice(possible_grades)
        for entry in output_without_words:
            if entry['label'] == 'Healthy Plant':
                if entry['score'] > 0.5:
                    grade = 'Grade A'
                    break
                elif entry['score'] > 0.25:
                    grade = 'Grade B'
                elif entry['score'] > 0.15:
                    grade = 'Grade C'
                elif entry['score'] > 0.01:
                    grade = 'Grade D'

        return render(request, 'op1.html', {'output': a, 'grade': grade, 'uploaded_image': latest_image})
    else:
        # Redirect to the page where image upload is performed
        return redirect('capturedimage')
