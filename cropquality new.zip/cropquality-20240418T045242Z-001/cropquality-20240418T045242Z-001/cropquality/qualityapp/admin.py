from django.contrib import admin
from .models import regist,UploadedImage
# Register your models here.
admin.site.register(regist)
admin.site.register(UploadedImage)